create procedure insert_test(IN test_name text, IN question_ids integer[], IN type_ids integer[], OUT new_test_id integer)
    language plpgsql
as
$$
DECLARE
    new_question_id integer;
    new_type_id     integer;
    question_len    integer;
    type_len        integer;
BEGIN
    IF (SELECT EXISTS(SELECT test_id FROM test WHERE test.name = test_name)) = true THEN
        RAISE EXCEPTION 'This test already exist';
    end if;

    INSERT INTO test(name)
    VALUES (test_name)
    RETURNING test_id INTO new_test_id;

    IF question_ids IS NOT NULL THEN
        question_len := array_length(question_ids, 1);
        IF (SELECT COUNT(question_id) = question_len FROM question WHERE question_id = ANY ((question_ids)::INT[])) = false THEN
            RAISE EXCEPTION 'Not found all selected questions';
        end if;
        FOREACH new_question_id IN ARRAY question_ids
            LOOP
                INSERT INTO test_question(test_id, question_id) VALUES (new_test_id, new_question_id);
            end loop;
    end if;

    IF type_ids IS NOT NULL THEN
        type_len := array_length(type_ids, 1);
        IF (SELECT COUNT(type_id) = type_len FROM test_type WHERE type_id = ANY ((type_ids)::INT[])) = false THEN
            RAISE EXCEPTION 'Not found all selected types';
        end if;

        FOREACH new_type_id IN ARRAY type_ids
            LOOP
                INSERT INTO test_test_type(test_id, type_id) VALUES (new_test_id, new_type_id);
            end loop;
    end if;

EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'ERROR CODE: %. MESSAGE TEXT: %', SQLSTATE, SQLERRM;
END;
$$;

alter procedure insert_test(text, integer[], integer[], out integer) owner to noh4uk;

